# BullBot

BullBot is a simple Python chatbot project.

## How to Run

1. Make sure you have Python 3 installed.
2. Clone the repository or download the code.
3. Run the bot:
   ```bash
   python main.py
   ```

## Usage
- Type anything, and BullBot will repeat it back.
- Type `quit`, `exit`, or `bye` to stop the bot.
